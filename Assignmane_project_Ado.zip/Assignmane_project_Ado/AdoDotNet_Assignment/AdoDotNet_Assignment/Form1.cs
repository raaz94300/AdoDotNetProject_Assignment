﻿using AdoDotNet_Assignment.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoDotNet_Assignment

{
    public partial class Form1 : Form
    {
        DepartmentLogic db;

        public Form1()
        {
            InitializeComponent();
            db = new DepartmentLogic();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            dataGridView1.Visible = true;

            dataGridView1.DataSource = db.getDeptDetails().Tables[0];


        }

        private void btninsert_Click(object sender, EventArgs e)
        {

            Department dpt = new Department();

            dpt.DeptId = Convert.ToInt32(tbid.Text);
            dpt.DeptName = tbname.Text.ToString();
            dpt.DeptLoc = tbloc.Text.ToString();
            dpt.MgrId = Convert.ToInt32(tbmgr.Text);

            string msg = db.insertData(dpt);

            MessageBox.Show(msg);
            dataGridView1.DataSource = db.getDeptDetails().Tables[0];

            tbid.Text = "";
            tbname.Text = "";
            tbloc.Text = "";
            tbmgr.Text = "";

        }

    }
}
