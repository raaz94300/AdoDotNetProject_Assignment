﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoDotNet_Assignment.Model
{
    class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Dob { get; set; }
        public string Phone { get; set; }
        public string Mail { get; set; }
        public float Salary { get; set; }
        public int DeptId { get; set; }

    }
}
