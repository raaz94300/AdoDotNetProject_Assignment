﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;


namespace AdoDotNet_Assignment.Model
{
    class DepartmentLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["empinfo"].ConnectionString;


        public DataSet getDeptDetails()
        {

            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string query = "select * from department";

            try
            {
                conn.Open();

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);

            }
            catch (Exception)
            {
                MessageBox.Show("Could not connect to DataBase!");
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }


        public string insertData(Department d)
        {

            string msg = null;
            SqlConnection conn = new SqlConnection(connStr);

            string proc1 = "dept_sp_insert";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(proc1, conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = d.DeptId;
                cmd.Parameters.Add("@DEPTNAME", SqlDbType.VarChar, 50).Value = d.DeptName;
                cmd.Parameters.Add("@DEPTLOC", SqlDbType.VarChar, 50).Value = d.DeptLoc;
                cmd.Parameters.Add("@MGR_ID", SqlDbType.Int).Value = d.MgrId;
                cmd.ExecuteNonQuery();

                msg = "Data Inserted Successfully...";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed...";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }
    }
}
