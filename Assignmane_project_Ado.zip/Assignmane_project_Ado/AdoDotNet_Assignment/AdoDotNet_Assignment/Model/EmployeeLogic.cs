﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace AdoDotNet_Assignment.Model
{
    class EmployeeLogic
    {

        private string connStr = ConfigurationManager.ConnectionStrings["empinfo"].ConnectionString;

        //getting all Employee Details.
        public DataSet getEmpDetails()
        {
            SqlConnection conn = new SqlConnection(connStr);

            string query = "select * from employee_details";
            DataSet ds = new DataSet();

            try
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);

            }
            catch (Exception)
            {
                MessageBox.Show("Could not connect to Database!");
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        //insert employee Function.
        public string insertEmp(Employee e)
        {

            string msg = null;

            SqlConnection conn = new SqlConnection(connStr);

            string pro_emp = "employee_sp_insert";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(pro_emp, conn);

                cmd.CommandType = CommandType.StoredProcedure;
                //MessageBox.Show(e.EmpId + " " + e.EmpName + " " + e.Dob + " " + e.Phone + " " + e.Mail + " " + e.Salary + " " + e.DeptId);
                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = e.EmpId;
                cmd.Parameters.Add("@EMPNAME", SqlDbType.VarChar, 50).Value = e.EmpName;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = e.Dob;
                cmd.Parameters.Add("@PHONE", SqlDbType.VarChar, 50).Value = e.Phone;
                cmd.Parameters.Add("@MAIL", SqlDbType.VarChar, 50).Value = e.Mail;
                cmd.Parameters.Add("@SALARY", SqlDbType.Float).Value = e.Salary;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = e.DeptId;

                cmd.ExecuteNonQuery();

                msg = "Data Inserted Successfully...";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed Successfully...!!";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }

        //getting employee Record by Name.
        public DataSet getEmpDataByName(string name)
        {

            SqlConnection conn = new SqlConnection(connStr);

            string query = "select * from employee_details where emp_name='" + name + "'";
            DataSet ds = new DataSet();

            try
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);
            }
            catch (Exception)
            {
                MessageBox.Show("Could not Connect to Database...!!");
            }
            finally
            {
                conn.Close();
            }
            return ds;

        }

        //getting employee details by salary.
        public DataSet getEmpDataBySalary(float salary)
        {

            SqlConnection conn = new SqlConnection(connStr);
            string query = "select * from employee_details where salary=" + salary;

            DataSet ds = new DataSet();

            try
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);

                MessageBox.Show("Data Inserted Successfully...");

            }
            catch (Exception)
            {
                MessageBox.Show("Could cpnnect to Database..!!");
            }
            finally
            {
                conn.Close();
            }
            return ds;

        }

        //getting employee record by id.
        public Employee findDataById(int id)
        {

            SqlConnection conn = new SqlConnection(connStr);
            string query = "select * from employee_details where emp_id=" + id;
            Employee e2 = new Employee();

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        e2.EmpId = Convert.ToInt32(reader.GetValue(0));
                        e2.EmpName = reader.GetValue(1).ToString();
                        e2.Dob = reader.GetValue(2).ToString();
                        e2.Phone = reader.GetValue(3).ToString();
                        e2.Mail = reader.GetValue(4).ToString();
                        e2.Salary = float.Parse(reader.GetValue(5).ToString());
                        e2.DeptId = Convert.ToInt32(reader.GetValue(6));

                    }

                }
                else
                {
                    e2 = null;

                }


            }
            catch (Exception)
            {
                MessageBox.Show("Could not connect to Database...!!");
            }
            finally
            {
                conn.Close();
            }
            return e2;

        }

        //UPDATE E
        public string updateRecord(Employee e)
        {

            string msg = null;
            SqlConnection conn = new SqlConnection(connStr);

            string pro_update = "employee_sp_update";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(pro_update, conn);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = e.EmpId;
                cmd.Parameters.Add("@EMPNAME", SqlDbType.VarChar, 50).Value = e.EmpName;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = e.Dob;
                cmd.Parameters.Add("@PHONE", SqlDbType.VarChar, 50).Value = e.Phone;
                cmd.Parameters.Add("@MAIL", SqlDbType.VarChar, 50).Value = e.Mail;
                cmd.Parameters.Add("@SALARY", SqlDbType.Float).Value = e.Salary;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = e.DeptId;


                cmd.ExecuteNonQuery();

                msg = "data updated successFully";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed SuccessFully!! ";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }

        //Delete the record by employee id
        public string deleteRecordById(int id)
        {

            string msg = null;

            SqlConnection conn = new SqlConnection(connStr);

            string proc1 = "employee_sp_delete";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(proc1, conn);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = id;


                cmd.ExecuteNonQuery();

                msg = "Record Deleted SuccessFully";

            }
            catch (Exception)
            {
                msg = "Procedure could not Executed!! ";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }

    }
}
