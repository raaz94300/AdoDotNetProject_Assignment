﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace AdoDotNet_Assignment.Model
{
    class JoiningLogic
    {


        private string connStr = ConfigurationManager.ConnectionStrings["empinfo"].ConnectionString;

        //Getting the data by employee and department table using inner join.
        public DataTable getCommonDetails()
        {

            DataTable table = new DataTable();

            SqlConnection conn = new SqlConnection(connStr);

            string query = "select E.emp_id,E.emp_name,E.salary,D.dept_id,D.dept_name," +
                "D.dept_location,D.manager_id FROM employee_details E INNER JOIN department D ON E.dept_id=D.dept_id";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(table);
                MessageBox.Show("Record found Successfully...");
            }
            catch (Exception)
            {
                MessageBox.Show("Could not Connect to Databae..!!");
            }
            finally
            {
                conn.Close();
            }

            return table;

        }

    }
}
